propPath=$1
version=$(cat $propPath | grep "version=" | cut -d "=" -f2)

json=$(
	cat <<EOF
{
    "name": "暗云调度",
    "author": "安与的安🐟",
    "version": "$version",
    "versionCode": 20251108,
    "features": {
        "strict": true,
        "pedestal": true
    },
    "module": "SCENE改（8gen3）",
    "state": "/data/adb/modules/SCENE改（8gen3）/mode.txt",
    "entry": "/data/powercfg.sh"
}
EOF
)
