#system/bin/sh
mode=/data/adb/modules/SCENE改（8gen3）/mode.txt

case $1 in
    "powersave" | "balance" | "performance" | "fast")
        switch_mode $1
        ;;
    "init")
        /data/powercfg.sh $(cat /data/adb/modules/SCENE改（8gen3）/mode.txt)
        ;;
    *)
        echo "Failed to apply unknown action '$1'."
        ;;
esac