#!/system/bin/sh
  
 MODDIR="${0%/*}"
  
   # 执行 setprop 
     setprop persist.sys.oiface.enable 2 2>/dev/null
  