 #!/system/bin/sh
 #
 # Magisk 模块卸载时执行：恢复特定文件权限为 777
 #
  
 # 定义路径 
 MODULE_PATH="/data/user/0/com.omarea.vtools/files/"
 VT_FILES="$MODULE_PATH"
  
 # 确保路径存在且可访问 
 if [ ! -d "$VT_FILES" ]; then
     echo "警告: 目录不存在或无法访问: $VT_FILES"
     exit 0
 fi
  
 # 定义要处理的文件扩展名和目标权限
 TARGET_PERM="777"
  
 echo "正在恢复 $VT_FILES 下的配置文件权限..."
  
 # 查找并恢复 .json 文件权限 
 find "$VT_FILES" -type f -name "*.json" -exec chmod "$TARGET_PERM" {} \; -exec echo "已恢复权限: {} ($TARGET_PERM)" \;
  
 # 查找并恢复 .CONF 文件权限（注意大小写敏感）
 find "$VT_FILES" -type f -name "*.CONF" -exec chmod "$TARGET_PERM" {} \; -exec echo "已恢复权限: {} ($TARGET_PERM)" \;
  
 # 查找并恢复 .sh 脚本文件权限
 find "$VT_FILES" -type f -name "*.sh" -exec chmod "$TARGET_PERM" {} \; -exec echo "已恢复权限: {} ($TARGET_PERM)" \;
  
 echo "权限恢复完成。"