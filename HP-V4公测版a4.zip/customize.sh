 #!/system/bin/sh
  
 MODDIR="${0%/*}"
  
 set_perm_recursive "$MODDIR" 0 0 0755 0755 
 set_perm "$MODDIR/service.sh" 0 0 0755 
  
 MODPATH="$MODPATH"
 JUMP_QQ="false"
 variant=""
 service_script=""
 module_prop_file=""
  
 ui_print() {
     echo "$1"
 }
  
 # 检测是否为骁龙8 Gen3芯片 
 qcom_chip=$(getprop ro.board.platform)
 soc_model=$(getprop ro.product.board)
 chipname=$(getprop ro.chipname)
 hardware=$(getprop ro.hardware)
 soc_manufacturer=$(getprop ro.soc.manufacturer) 
 soc_id=$(getprop ro.soc.model)                
 
 cpu_info=$(cat /proc/cpuinfo | grep -i 'Hardware\|CPU Architecture\|Processor\|Implementer' | head -n 10)
  
 is_gen3=false
  
 case "${chipname}_${soc_model}_${qcom_chip}_${hardware}_${soc_id}" in 
 
 *"8gen3"* | *"8Gen3"* | *"8 gen3"* | *"SM8650"* | *"pineapple"* | *"kalama"*)
     is_gen3=true ;;
 esac 
  
 if [ "$is_gen3" != "true" ]; then
     if echo "$cpu_info" | grep -qi "ARMv9" && \
 
 echo "$cpu_info" | grep -qiE "X4|A720|A520"; then
 if [ "$soc_manufacturer" = "QCOM" ] || echo "$soc_id" | grep -qi "8650"; then
             is_gen3=true
         fi 
     fi
 fi
  
 if [ "$is_gen3" != "true" ]; then 
     ui_print "**********************************************"
     ui_print "❌ 验证失败：设备参数不符合骁龙8 Gen3特征"
     ui_print "----------------------------------------------"
     ui_print "核心参数检测结果："
     ui_print "ro.chipname=$chipname"
     ui_print "ro.soc.model=$soc_id"
     ui_print "ro.soc.manufacturer=$soc_manufacturer"
     ui_print "ro.product.board=$soc_model"
     ui_print "ro.board.platform=$qcom_chip"
     ui_print "ro.hardware=$hardware"
     echo "$cpu_info" | while read line; do 
         ui_print "CPUINFO: $line"
     done 
     ui_print "----------------------------------------------"
     ui_print "⚠️ 请确认："
     ui_print "设备是否8gen3处理器"
     ui_print "**********************************************"
     sleep 10
     exit 1 
 fi 
  
 ui_print "✅ 骁龙8 Gen3芯片验证通过：$soc_id"
  
 ui_print "=============================="
 ui_print "  ♥-🐟-♥二改HP调度模块安装"
 ui_print "=============================="
 ui_print "  是否禁用oiface："
 ui_print "  音量➕ ＝否"
 ui_print "  音量➖ ＝是（建议）"
 ui_print "=============================="
  
 key=""
 while true; do
 
 key=$(getevent -qlc 1 | awk '{ print $3 }' | grep -E 'KEY_VOLUMEUP|KEY_VOLUMEDOWN' | head -n1)
     if [ -n "$key" ]; then 
         case "$key" in
             KEY_VOLUMEUP)
                 variant="official"
                 service_script="service_official.sh"
                 module_prop_file="moduleV2.prop"
                 break
                 ;;
             KEY_VOLUMEDOWN)
                 variant="custom"
                 service_script="service_custom.sh"
                 module_prop_file="moduleV1.prop"
                 break 
                 ;;
         esac 
     fi
 done 
  
 ui_print "  已选择版本：$variant"
 ui_print "  使用的服务脚本：$service_script"
 ui_print "  使用的模块配置：$module_prop_file"
  
 mv "$MODPATH/common/$service_script" "$MODPATH/service.sh"
 mv "$MODPATH/mmmm/$module_prop_file" "$MODPATH/module.prop"
  
 set_perm "$MODPATH/service.sh" 0 0 0755
 set_perm "$MODPATH/module.prop" 0 0 0644
  
 ui_print "- 清理未使用文件..."
 rm -rf "$MODPATH/common"
 rm -rf "$MODPATH/mmmm"
  
 ui_print ""
 ui_print "*********************************************"
 ui_print "请使用正版scene9，打开HP调度"
 ui_print "此调度仅为略改scene HP调度的部分参数，"
 ui_print "建议搭配我（酷安@安与的安）主页置顶教程食用最佳！"
 ui_print "非ColorOS系统请勿刷入oki潘多拉内核！"
 ui_print "感谢scene作者嘟嘟斯基和枫老板的模块借鉴！"
 ui_print "*********************************************"
 sleep 5 
  
 ui_print ""
 ui_print "*********************************************"
 ui_print "是否加入安の调度小窝🐟？"
 ui_print "音量+ ＝ 加入QQ群"
 ui_print "音量- ＝ 跳过"
 ui_print "*********************************************"
  
 key=""
 while [ -z "$key" ]; do
 
 key=$(getevent -qlc 1 | awk '{print $3}' | grep -E 'KEY_VOLUMEUP|KEY_VOLUMEDOWN' | head -n1)
     sleep 0.1 
 done
  
 [ "$key" = "KEY_VOLUMEUP" ] && JUMP_QQ="true"
  
 [ "$JUMP_QQ" = "true" ] && {
     ui_print "- 正在加入QQ群..."
     am start -a android.intent.action.VIEW \
 -d "mqqopensdkapi://bizAgent/qm/qr?url=https%3A%2F%2Fqm.qq.com%2Fq%2FfBrrRcWZxu" >/dev/null 2>&1 &
     sleep 1
     
 
 pm list packages | grep com.tencent.mobileqq >/dev/null || \
         am start -a android.intent.action.VIEW \
 -d "https://qm.qq.com/q/fBrrRcWZxu" >/dev/null 2>&1 &
 }
 sh "$MODPATH/vtools/init_vtools.sh" "$(realpath $MODPATH/module.prop)"
 ui_print "- 安装完成，开始享受吧！"
 ui_print "- 正在使用的服务脚本：service.sh (基于 $service_script)"
 ui_print "- 正在使用的模块配置：module.prop (基于 $module_prop_file)"
  
 exit 0