 #!/system/bin/sh
  
 MODDIR="${0%/*}"
 VT_FILES="/data/data/com.omarea.vtools/files"
  
 get_board_platform() {
     getprop ro.board.platform 
 }
  
 is_8gen3() {
     [ "$(get_board_platform)" = "pineapple" ]
 }
  
 wait_and_prepare() {
     while [ ! -d "$VT_FILES" ]; do 
         sleep 2 
     done 
     chmod 755 "$VT_FILES"
     chown system:system "$VT_FILES"
 }
  
 copy_apps_json() {
     local config_dir="$MODDIR/config/8gen3"
     local target_dir="$VT_FILES"
     
     if [ ! -f "$config_dir/_Apps.json" ]; then 
         log -p w -t "SCENE改（8gen3）" "_Apps.json 源文件不存在: $config_dir/_Apps.json"
         return 1 
     fi 
     
     log -p i -t "SCENE改（8gen3）" "覆盖 _Apps.json 到 $target_dir"
     chmod 755 "$target_dir/_Apps.json" 2>/dev/null || true 
     cp -f "$config_dir/_Apps.json" "$target_dir/"
     chmod 555 "$target_dir/_Apps.json"
 }
  
 copy_config_files() {
     local config_dir="$MODDIR/config/8gen3"
     local target_dir="$VT_FILES"
  
     if [ ! -d "$config_dir" ]; then 
         log -p w -t "SCENE改（8gen3）" "配置目录不存在: $config_dir"
         return 1 
     fi 
  
     log -p i -t "SCENE改（8gen3）" "覆盖配置文件到 $target_dir"
     chmod 755 "$target_dir/_ELP.json" 2>/dev/null || true 
     chmod 755 "$target_dir/manifest.json" 2>/dev/null || true 
     chmod 755 "$target_dir/_Games.json" 2>/dev/null || true 
     chmod 755 "$target_dir/powercfg.sh" 2>/dev/null || true 
     chmod 755 "$target_dir/profile.json" 2>/dev/null || true 
  
     copy_apps_json 
     cp -f "$config_dir/_ELP.json" "$target_dir/"
     cp -f "$config_dir/manifest.json" "$target_dir/"
     cp -f "$config_dir/_Games.json" "$target_dir/"
     cp -f "$config_dir/powercfg.sh" "$target_dir/"
     cp -f "$config_dir/profile.json" "$target_dir/"
  
     chmod 555 "$target_dir/_ELP.json"
     chmod 555 "$target_dir/manifest.json"
     chmod 555 "$target_dir/_Games.json"
     chmod 555 "$target_dir/powercfg.sh"
     chmod 555 "$target_dir/profile.json"
 }
  
 
  
 
  
 run_core_operations() {
     if is_8gen3; then 
         wait_and_prepare 
         copy_config_files  
         log -p i -t "scene" "8gen3 初始化/重载完成"
     else 
         log -p w -t "scene" "非 8gen3 设备"
     fi 
 }
  
 delayed_apps_update() {
     sleep 60 
     if is_8gen3; then 
         log -p i -t "SCENE改（8gen3）" "执行延迟更新"
         if [ -d "$VT_FILES" ]; then 
             copy_apps_json 
         else 
             wait_and_prepare 
             copy_apps_json 
         fi 
     fi 
 }
  
 main() {
     sleep 20 
     run_core_operations 
     delayed_apps_update &
 }
  
 main