#!/system/bin/sh
SKIPUNZIP=0
 [ -z "$MODPATH" ] && MODPATH="$1"
 [ -z "$LOG_FILE" ] && LOG_FILE="/data/adb/ksu_install.log"
 
 ui_print() {
     echo "$1"
     if [ -f "/proc/ksu" ]; then
         echo "[$(date "+%m-%d %T")] $1" >> $LOG_FILE
         log -p i -t "KSuModule" "$1"
     fi 
 }
 
 ksu_get_key() {
 
 timeout 10 getevent -qlc 1 | awk '{print $3}' | grep -E 'KEY_VOLUMEUP|KEY_VOLUMEDOWN' | head -n1
 }
 
 SKIPMOUNT=false
 PROPFILE=true 
 POSTFSDATA=true
 LATESTARTSERVICE=true
 
 MODDIR="${0%/*}"
 MODPATH="$MODPATH"
 JUMP_QQ="false"
 
 set_perm_recursive $MODPATH 0 0 0755 0644 
 set_perm_recursive "$MODDIR" 0 0 0755 0755 
 set_perm "$MODDIR/service.sh" 0 0 0755 
 
 ui_print() {
     echo "$1"
 }
 
 get_coolapk_user_name() {
     for i in /data/user/0/com.coolapk.market/shared_prefs/*preferences*.xml; do
         username="$(grep '<string name="username">' "${i}" | sed 's/.*"username">//g;s/<.*//g')"
         [[ -n "${username}" ]] && {
             echo "${username}"
             break
         }
     done 
 }
 
 get_github_user() {
     local github_name="$(dumpsys content | grep -Eo 'Account[[:space:]].*u[0-9]{1,3}.*com\.github\.android' | 
                         sed 's/Account[[:space:]]//g;s/[[:space:]]u[0-9].*//g' | sort -u | head -n 1)"
     echo "${github_name}"
 }
 
 hello_master() {
     echo ""
     if test -n "$(getprop persist.sys.device_name)"; then 
         echo "－ ● 您好！$(getprop persist.sys.device_name)！●"
     elif test "$(get_coolapk_user_name)" != ""; then 
         echo "－ ● 您好！$(get_coolapk_user_name)！●"
     elif [[ -n "$(get_github_user)" ]]; then
         echo "－ ● 您好！$(get_github_user)！●"
     elif test -n "$(pm list users | cut -d : -f2 )"; then 
         echo "－ ● 您好！$(pm list users | cut -d : -f2 )！●"
     fi
     echo "－ ● 欢迎使用本模块！●"
 }
 
 validate_sd8gen3() {
     qcom_chip=$(getprop ro.board.platform)
     soc_model=$(getprop ro.product.board)
     chipname=$(getprop ro.chipname)
     hardware=$(getprop ro.hardware)
     soc_manufacturer=$(getprop ro.soc.manufacturer) 
     soc_id=$(getprop ro.soc.model)                
 
 
 cpu_info=$(cat /proc/cpuinfo | grep -i 'Hardware\|CPU Architecture\|Processor\|Implementer' | head -n 10)
    
     is_gen3=false
     case "${chipname}_${soc_model}_${qcom_chip}_${hardware}_${soc_id}" in 
 
 *"8gen3"* | *"8Gen3"* | *"8 gen3"* | *"SM8650"* | *"pineapple"* | *"kalama"*)
             is_gen3=true 
         ;;
     esac 
    
     [[ "$is_gen3" != "true" ]] && {
         if echo "$cpu_info" | grep -qi "ARMv9" && 
 
 echo "$cpu_info" | grep -qiE "X4|A720|A520"; then
             [[ "$soc_manufacturer" = "QCOM" || "$soc_id" =~ "8650" ]] && is_gen3=true
         fi 
     }
    
     [[ "$is_gen3" != "true" ]] && {
         ui_print "╔════════════════════════════════════════╗"
         ui_print "❌ 验证失败：设备参数不符合骁龙8 Gen3特征"
         ui_print "╠════════════════════════════════════════╣"
         ui_print "📊 核心参数检测结果："
         ui_print "   ro.chipname=$chipname"
         ui_print "   ro.soc.model=$soc_id"
         ui_print "   ro.soc.manufacturer=$soc_manufacturer"
         ui_print "   ro.product.board=$soc_model"
         ui_print "   ro.board.platform=$qcom_chip"
         ui_print "   ro.hardware=$hardware"
         echo "$cpu_info" | while read line; do 
             ui_print "   CPUINFO: $line"
         done 
         ui_print "╠════════════════════════════════════════╣"
         ui_print "⚠️ 请确认："
         ui_print "   设备是否为骁龙8 Gen3处理器"
         ui_print "╚════════════════════════════════════════╝"
         sleep 10 
     }
    
     ui_print "✅ 骁龙8 Gen3芯片验证通过：$soc_id"
 }
 
 ui_print "╔══════════════════════════════════╗"
 ui_print "   ♥-🐟-♥ 二改HP调度模块安装程序"
 ui_print "╚══════════════════════════════════╝"
 
 validate_sd8gen3
 
 hello_master
 ui_print "－ ● 部分代码来源 酷安@10007！●"
 
 ui_print "╔══════════════════════════════════╗"
 ui_print "  是否加入安の调度小窝🐟？"
 ui_print "  音量➕ ＝ 加入QQ群"
 ui_print "  音量➖ ＝ 跳过"
 ui_print "╚══════════════════════════════════╝"
 
 key=""
 while [ -z "$key" ]; do 
 
 key=$(getevent -qlc 1 | awk '{print $3}' | grep -E 'KEY_VOLUMEUP|KEY_VOLUMEDOWN' | head -n1)
     sleep 0.1 
 done
 
 [[ "$key" = "KEY_VOLUMEUP" ]] && JUMP_QQ="true"
 
 [[ "$JUMP_QQ" = "true" ]] && {
     ui_print "- 正在加入QQ群..."
     am start -a android.intent.action.VIEW -d "mqqopensdkapi://bizAgent/qm/qr?url=https%3A%2F%2Fqm.qq.com%2Fq%2FfBrrRcWZxu" >/dev/null 2>&1 &
     sleep 1
 
 pm list packages | grep com.tencent.mobileqq >/dev/null ||
         am start -a android.intent.action.VIEW -d "https://qm.qq.com/q/fBrrRcWZxu" >/dev/null 2>&1 &
 }
 
 ui_print "╔══════════════════════════════════╗"
 ui_print "✅ 安装完成，开始享受吧！"
 ui_print "╠══════════════════════════════════╣"
 ui_print "📢 温馨提示："
 ui_print "   1. 请使用正版Scene9开启HP调度"
 ui_print "   2. 建议搭配酷安@安与的安置顶教程使用"
 ui_print "   3. 非ColorOS系统请勿刷入oki潘多拉内核"
 ui_print "   4. 已默认禁用oiface，如需恢复请执行模块按钮"
 ui_print "   5. 如需卸载，请执行模块按钮恢复官方HP后卸载模块"
 ui_print "╚══════════════════════════════════╝"
 
 