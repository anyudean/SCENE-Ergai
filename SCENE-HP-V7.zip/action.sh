 #!/system/bin/sh 
 MODDIR="/data/adb/modules/SCENE-⁽⁸ᵍᵉⁿ³⁾/"
 COMMON_DIR="$MODDIR/common"
 POST_FS_FILE="$MODDIR/post-fs-data.sh"
  
 wait_key() {
   getevent -qt 1 >/dev/null 2>&1 
   while true; do 
     event=$(getevent -lqc 1 2>/dev/null | {
       while read -r line; do 
         case "$line" in 
           *KEY_VOLUMEDOWN*DOWN*) echo "down" && break ;;
           *KEY_VOLUMEUP*DOWN*) echo "up" && break ;;
         esac 
       done 
     })
     [ -n "$event" ] && echo "$event" && return 
     usleep 50000 
   done 
 }
  
 show_menu() {
   clear 
   echo 
   echo "           🎯 SCENE 配置  "
   echo "      风萧萧兮易水寒，壮士一去兮不复还"
   echo 
   # ========== 双线边框开始 ==========
   echo "   ╔═══════════════════╦═══════════════════╗"
   echo "   ║   步骤1: oiface      步骤2: 还原与写入  ║"
   echo "   ║  (官方线程启禁)        (HP调整)       ║"
   echo "   ╠═══════════════════╬═══════════════════╣"
   
   # 第一步选项
   case $1 in 
     1) echo "     ➤ [1] 禁用 oiface    ║" ;;
     2) echo "   ║    ► [1] 禁用 oiface    ║" ;;
     3) echo "      ✔ [1] 禁用 oiface   " ;;
   esac 
   case $2 in 
     1) echo "   ║   ➤ [2] 启用 oiface   " ;;
     2) echo "   ║    ► [2] 启用 oiface    ║" ;;
     3) echo "      ✔ [2] 启用 oiface   " ;;
   esac 
   case $3 in 
     1) echo "   ║   ➤ [3] 跳过配置     " ;;
     2) echo "   ║    ► [3] 跳过配置      ║" ;;
     3) echo "      ✔ [3] 跳过配置     " ;;
   esac 
   
   echo "  ═══════════════════╬═══════════════════╣"
   
   # 第二步选项 
   case $4 in 
     1) echo "   ║   ➤ [1] 恢复官方HP    ║" ;;
     2) echo "      ► [1] 恢复官方HP    ║" ;;
     3) echo "      ✔ [1] 恢复官方HP    ║" ;;
   esac 
   case $5 in 
     1) echo "     ➤ [2] 写入二改HP    ║" ;;
     2) echo "      ► [2] 写入二改HP   " ;;
     3) echo "   ║    ✔ [2] 写入二改HP    ║" ;;
   esac 
   case $6 in 
     1) echo "     ➤ [3] 跳过配置      ║" ;;
     2) echo "      ► [3] 跳过配置     " ;;
     3) echo "   ║    ✔ [3] 跳过配置      ║" ;;
   esac 
   
   echo "   ╚═══════════════════╩═══════════════════╝"
   # ========== 双线边框结束 ==========
   echo 
   echo "  操作说明："
   echo "   🔼 音量▲ = 切换选项 |  🔽 音量▼ = 确认选择"
   echo "    🌟 当前步骤: $7  🌟"
   echo 
 }
  
 step1_current=1 
 while true; do 
   show_menu \
     $([ $step1_current -eq 1 ] && echo 1 || echo 2) \
     $([ $step1_current -eq 2 ] && echo 1 || echo 2) \
     $([ $step1_current -eq 3 ] && echo 1 || echo 2) \
     2 2 2 \
     "oiface配置 (1/2)"
   
   choice=$(wait_key)
   
   case "$choice" in 
     "up")
       step1_current=$((step1_current % 3 + 1))
       ;;
     "down")
       # ===== 双线提示框开始 =====
       echo 
       echo "   ╔══════════════════════════════════╗"
       case $step1_current in 
         1)
           echo "   ║ ✅ 已选择：禁用 oiface           "
           [ -f "$COMMON_DIR/service_custom.sh" ] && {
             cp "$COMMON_DIR/service_custom.sh" "$POST_FS_FILE"
             sh "$POST_FS_FILE"
             echo "   ║ ✔ 成功禁用：oiface               "
           } || echo "     错误：service_custom.sh 缺失 "
           ;;
         2)
           echo "   ✅ 已选择：启用 oiface            ║"
           [ -f "$COMMON_DIR/service_official.sh" ] && {
             cp "$COMMON_DIR/service_official.sh" "$POST_FS_FILE"
             sh "$POST_FS_FILE"
             echo "   ✔ 成功激活：oiface               "
           } || echo "     错误：service_official.sh 缺失║"
           ;;
         3)
           echo "    ⏩ 已跳过 oiface 配置            ║"
           ;;
       esac 
       echo "   ╚══════════════════════════════════╝"
       # ===== 双线提示框结束 ===== 
       sleep 1 
       break 
       ;;
   esac 
 done 
  
 {
   input flush 2>/dev/null 
   sleep 0.5 
 }
  
 step2_current=1 
 while true; do 
   show_menu \
     3 3 3 \
     $([ $step2_current -eq 1 ] && echo 1 || echo 2) \
     $([ $step2_current -eq 2 ] && echo 1 || echo 2) \
     $([ $step2_current -eq 3 ] && echo 1 || echo 2) \
     "HP选择 (2/2)"
   
   choice=$(wait_key)
   
   case "$choice" in 
     "up")
       step2_current=$((step2_current % 3 + 1))
       ;;
     "down")
       # ===== 双线提示框开始 ===== 
       echo 
       echo "  ══════════════════════════════════╗"
       case $step2_current in 
         1)
           echo "    正在恢复官方HP...            "
           MIGRATION_SRC="$MODDIR/666"
           VT_DATA_DIR="/data/data/com.omarea.vtools/files"
           
           [ -d "$MIGRATION_SRC" ] && {
             cp -r "$MIGRATION_SRC"/* "$VT_DATA_DIR"/
             find "$VT_DATA_DIR" -type f -exec chmod 777 {} +
             echo "   ✅ HP配置还原成功！            "
           } || echo "     错误：配置目录不存在       "
           ;;
         2)
           echo "   ║  正在写入二改HP...            "
           SERVICE_SH="$MODDIR/service.sh"
           [ -f "$SERVICE_SH" ] && {
             sh "$SERVICE_SH"
             echo "   ✅ 二改HP已生效！              "
           } || echo "     错误：service.sh 缺失     "
           ;;
         3)
           echo "   ║   已跳过操作                 "
           ;;
       esac 
       echo "  ══════════════════════════════════╝"
       # ===== 双线提示框结束 =====
       sleep 1 
       break 
       ;;
   esac 
 done 
  
 echo 
 echo "    ╔═════════════════════════════════╗"
 echo "    ║          🎉 所有操作已完成   🎉         ║"
 echo "                                    "
 echo "    ║    系统将在3秒后自动退出...     "
 echo "    ╚═════════════════════════════════╝" 
  
 for i in 3 2 1; do 
   echo -ne "\033[2K\r⏱️  退出倒计时: ${i}秒"
   sleep 1 
 done 
 echo -e "\033[2K\r"
 exit 0