 #!/system/bin/sh 
     stop oiface  