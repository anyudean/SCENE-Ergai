#!/system/bin/sh
  
 MODDIR="${0%/*}"
  
   # 启用oiface
     setprop persist.sys.oiface.enable 2 2>/dev/null
  